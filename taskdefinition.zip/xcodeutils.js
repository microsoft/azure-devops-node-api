"use strict";
const tl = require('vsts-task-lib/task');
function setTaskState(variableName, variableValue) {
    if (agentSupportsTaskState()) {
        tl.setTaskVariable(variableName, variableValue);
    }
}
exports.setTaskState = setTaskState;
function getTaskState(variableName) {
    if (agentSupportsTaskState()) {
        return tl.getTaskVariable(variableName);
    }
}
exports.getTaskState = getTaskState;
function agentSupportsTaskState() {
    var agentSupportsTaskState = true;
    try {
        tl.assertAgent('2.115.0');
    }
    catch (e) {
        agentSupportsTaskState = false;
    }
    return agentSupportsTaskState;
}
